##################################
#####   Compile Latex file   #####
#####   Author: Wei Si       #####
#####   Date: Jan. 7. 2019   #####
##################################

##### Please replace "main" by your file name;
##### Give permission by this command: chmod u+x Makefile.sh;
##### ./Makefile.sh ( for compiling );
##### ./Makefile.sh view ( for reading );
##### ./Makefile.sh clean ( for cleaning );

#!/bin/bash
clear

main="Chinese_template"
all_file=${main}.tex

if [ $# -eq 0 ]
then
	xelatex ${main}.tex
	bibtex  ${main}.aux
	pdflatex ${main}.tex
	evince  ${main}.pdf&
else
	if [ $1 == "view" ]
	then
		evince ${main}.pdf&
	elif [ $1 == "clean" ]
	then
		rm -f *.ps *.dvi *.aux *.toc *.idx *.ind *.ilg *.log *.out *~\
			*.tid *.tms *.pdf *.bak *.blg *.bbl
    else
        echo "empty, view or clean"
	fi
fi

